# flake8: noqa
from .core import *
from .channels import *
SCHEMA_VERSION = 'v4.0.0'
SCHEMA_URL = 'https://vega.github.io/schema/vega-lite/v4.0.0.json'
